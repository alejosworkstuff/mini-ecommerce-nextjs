import Link from 'next/link'

interface PageProps {
  params: {
    id: string;
  };
}

export default function ProductDetail({ params }: PageProps) {
  const { id } = params;

  return (
    <main className="p-8">
      <h1 className="text-2xl font-bold">Product #{id}</h1>

      <p className="mt-4 text-gray-600">
        This is the product detail with ID {id}.
      </p>

      <Link
        href="/cart"
        className="mt-6 inline-block bg-violet-600 text-white px-4 py-2 rounded-xl hover:bg-violet-700"
      >
        Add to cart
      </Link>
    </main>
  );
}
