"use client";

import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { CartItem, addItem, removeItem, loadCart, saveCart } from "@/lib/cart";

interface CartContextType {
  cart: CartItem[];
  addToCart: (id: string) => void;
  removeFromCart: (id: string) => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {


 const [cart, setCart] = useState<CartItem[]>(() => loadCart());

  useEffect(() => {
    saveCart(cart);
  }, [cart]);

  const addToCart = (id: string) => {
    setCart(prev => addItem(prev, id));
  };

  const removeFromCart = (id: string) => {
    setCart(prev => removeItem(prev, id));
  };

  return (
    <CartContext.Provider value={{ cart, addToCart, removeFromCart }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
}
