export default function HomePage() {
    return (
        <main className="p-8">
            <h1 className="text-3xl font-bold">Mini Ecommerce</h1>
            <p className="mt-2 text-lg text-gray-600">Welcome to demonstration store</p>

        <a
        href="/products"
        className="mt-6 inline-block bg-violet-600 text-white px-4 py-2 rounded-xl hover:bg-violet-700">
            View Products
        </a>
        </main>
    );
}