import { CartProvider } from "./context/CartContext"
import Header from "../components/Header";

export const metadata = {
    title: 'mini-ecommerce',
    description: "Fake MercadoLibre clone",
}

export default function RootLayout ({ children }: { children: React.ReactNode }) {
    return (
        <html lang="en">
        <body>{children}
        <Header />
        </body>
        </html>
    );
}