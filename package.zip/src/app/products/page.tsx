export default function ProductsPage () {
    const products = [
        { id: 1, name: "Laptop Pro", price: 1500 },
        { id: 2, name: "Headphones X Pro", price: 200 },
        { id: 3, name: "Gaming Mouse", price: 160 },
    ];


return (
    <main className="p-8">
        <h1 className="text-2xl font-bold mb-4">Products</h1>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {products.map((p) => (
            <a
                key={p.id}
                href={`/product/${p.id}`}
                className="border rounded-xl p-4 hover:shadow-xl transition"
                >
                <h3 className="font-semibold">{p.name}</h3>
                <p className="text-gray-600">${p.price}</p>
            </a>
            ))}
        </div>
    </main>
);
}