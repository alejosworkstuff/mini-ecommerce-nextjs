interface CartPageProps {
    searchParams?: {
    add?: string;
    };
}

export default function cartPage({ searchParams}: CartPageProps) {
    const addedProductId = searchParams?.add;

    return (
        <main className="p-8">
            <h1 className="text-2xl font-bold">Cart</h1>

            {addedProductId ? (
                <p className="mt-4">
                    Product <strong>#{addedProductId}</strong> has been added to your cart.
                </p>
            ) : (
                <p className="mt-4">Your cart is empty</p>
            )}
        </main>
    );
}